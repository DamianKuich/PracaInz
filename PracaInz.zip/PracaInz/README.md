# PracaInz
Repozytorium do przechowywania pracy inżynierskiej.

Szkielet na podstawie: https://github.com/bprzybylski/amuthesis
